export interface Alumno {
  id: string;
  nombre: string;
  apellido: string;
  estado: string;
  edad: number;
}
