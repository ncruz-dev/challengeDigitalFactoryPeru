import { Component, OnInit, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { catchError, of, finalize } from 'rxjs';

import { MatSnackBar } from '@angular/material/snack-bar';
import { Alumno } from '../../models/alumnos.model';

@Component({
  selector: 'app-alumnos',
  templateUrl: './alumnos.component.html',
  styleUrl: './alumnos.component.css'
})
export class AlumnosComponent implements OnInit {

  private http = inject(HttpClient);
    private fb = inject(FormBuilder);
    private snackBar = inject(MatSnackBar);
    private readonly API_URL = 'http://localhost:8080/api/alumnos';

    vistaActual = signal<'list' | 'create'>('list');
    alumnos = signal<Alumno[]>([]);
    cargando = signal<boolean>(false);
    columnasMostradas: string[] = ['id', 'nombre', 'apellido', 'edad', 'estado'];

    private mockDatabase: Alumno[] = [
      { id: 'ALU-001', nombre: 'Carlos', apellido: 'Gómez', estado: 'activo', edad: 15 },
      { id: 'ALU-002', nombre: 'Lucía', apellido: 'Méndez', estado: 'activo', edad: 16 }
    ];

    alumnoForm: FormGroup = this.fb.group({
      id: [''],// Validators.required],
      nombre: [''],//, Validators.required],
      apellido: [''],//, Validators.required],
      estado: ['activo'],//, Validators.required],
      edad: [''],//, [Validators.required, Validators.min(3), Validators.max(100)]]
    });

    ngOnInit() { this.cargarAlumnos(); }

    cambiarVista(vista: 'list' | 'create') {
      this.vistaActual.set(vista);
      if (vista === 'list') this.cargarAlumnos();
    }

    cargarAlumnos() {
      this.cargando.set(true);
      this.http.get<Alumno[]>(`${this.API_URL}/activos`)
        .pipe(
          catchError(() => of(this.mockDatabase.filter(a => a.estado === 'activo'))),
          finalize(() => this.cargando.set(false))
        )
        .subscribe((data) => this.alumnos.set(data));
    }

    guardarAlumno() {
      if (this.alumnoForm.invalid) return;
      this.cargando.set(true);
      const nuevo = this.alumnoForm.value;
      this.http.post(this.API_URL, nuevo)
        .pipe(
          catchError(() => {
            this.mockDatabase.push(nuevo);
            return of(true);
          }),
          finalize(() => this.cargando.set(false))
        )
        .subscribe(() => {
          this.alumnoForm.reset({ estado: 'activo' });
          this.cambiarVista('list');
        });
    }

    private mostrarNotificacion(mensaje: string) {
      this.snackBar.open(mensaje, 'Cerrar', { duration: 3000, verticalPosition: 'bottom' });
    }

}
